export interface LayoutConfig {
    // layoutType?: string;
    layoutWidth: string;
    menuPosition: string;
    leftSidebarTheme: string;
    leftSidebarType: string;
    showSidebarUserInfo: boolean;
    topbarTheme: string;
}