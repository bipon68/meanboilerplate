export interface ChartWidget {
    id: number;
    title: string;
    stats: string;
    chartColor: string[];
    chartData: number[];
}