export interface StatisticsWidget1 {
    id?: number;
    title?: string;
    icon?: string;
    variant?: string;
    stats?: number | string;
}