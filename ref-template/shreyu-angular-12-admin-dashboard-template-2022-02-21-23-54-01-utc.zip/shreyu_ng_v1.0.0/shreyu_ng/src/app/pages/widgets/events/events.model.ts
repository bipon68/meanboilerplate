export interface EventSchedule {
    id: number;
    title: string;
    time: string;
}