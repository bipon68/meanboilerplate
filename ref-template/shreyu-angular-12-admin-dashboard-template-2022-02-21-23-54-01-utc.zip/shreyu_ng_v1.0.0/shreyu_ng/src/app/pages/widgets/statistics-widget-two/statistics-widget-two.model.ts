export interface StatisticsWidget2 {
    id?: number;
    title?: string;
    subTitle?: string;
    stats?: number | string;
    progress?: number;
    variant?: string;
}