export interface Activity {
    id?: number;
    avatar?: string;
    userInitial?: string;
    variant?: string;
    activityTitle?: string;
    time?: string;
}