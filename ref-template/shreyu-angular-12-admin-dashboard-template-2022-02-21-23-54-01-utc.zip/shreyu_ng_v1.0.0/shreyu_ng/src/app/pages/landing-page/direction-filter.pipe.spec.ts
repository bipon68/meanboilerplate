import { DirectionFilterPipe } from './direction-filter.pipe';

describe('DirectionFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DirectionFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
