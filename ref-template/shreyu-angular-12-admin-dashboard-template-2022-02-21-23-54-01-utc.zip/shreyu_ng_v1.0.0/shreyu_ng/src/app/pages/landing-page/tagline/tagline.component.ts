import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-tagline',
  templateUrl: './tagline.component.html',
  styleUrls: ['./tagline.component.scss']
})
export class TaglineComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
