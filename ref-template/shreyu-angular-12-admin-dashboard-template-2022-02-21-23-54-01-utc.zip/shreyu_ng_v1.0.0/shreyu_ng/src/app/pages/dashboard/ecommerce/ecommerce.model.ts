export interface OrderItem {
    id?: number;
    order_id?: string;
    productName?: string;
    customer?: string;
    price?: number;
    status?: string;
}