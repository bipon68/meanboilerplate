import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ui-accordions',
  templateUrl: './accordions.component.html',
  styleUrls: ['./accordions.component.scss']
})
export class AccordionsComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
