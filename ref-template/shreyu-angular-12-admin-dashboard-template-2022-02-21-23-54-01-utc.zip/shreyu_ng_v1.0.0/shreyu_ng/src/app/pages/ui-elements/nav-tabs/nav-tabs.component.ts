import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ui-nav-tabs',
  templateUrl: './nav-tabs.component.html',
  styleUrls: ['./nav-tabs.component.scss']
})
export class NavTabsComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
