import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ui-tooltips',
  templateUrl: './tooltips.component.html',
  styleUrls: ['./tooltips.component.scss']
})
export class TooltipsComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
