import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ui-toasts',
  templateUrl: './toasts.component.html',
  styleUrls: ['./toasts.component.scss']
})
export class ToastsComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
