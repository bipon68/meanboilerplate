export interface Variant {
    name: string;
    color: string;
}