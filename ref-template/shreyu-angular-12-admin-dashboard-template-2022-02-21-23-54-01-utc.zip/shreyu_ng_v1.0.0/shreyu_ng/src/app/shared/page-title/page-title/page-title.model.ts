export interface BreadcrumbItem {
    label?: string;
    path?: string;
    active?: boolean;
}
