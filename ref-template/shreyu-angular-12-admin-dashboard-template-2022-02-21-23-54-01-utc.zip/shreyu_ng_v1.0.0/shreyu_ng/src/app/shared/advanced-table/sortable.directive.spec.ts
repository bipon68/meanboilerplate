import { NgbSortableHeaderDirective } from './sortable.directive';

describe('NgbSortableHeaderDirective', () => {
  it('should create an instance', () => {
    const directive = new NgbSortableHeaderDirective();
    expect(directive).toBeTruthy();
  });
});
