export interface Member {
    id: number,
    name: string,
    avatar: string,
    designation: string
}