export interface OverviewItem {
    title?: string;
    stats?: string | number;
    icon?: string;
}