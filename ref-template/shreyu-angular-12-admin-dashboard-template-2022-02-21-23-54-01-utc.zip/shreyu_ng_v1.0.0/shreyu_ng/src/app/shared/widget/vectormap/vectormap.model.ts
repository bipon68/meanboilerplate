export interface markers {
    name?: string;
    coords: number[];
}