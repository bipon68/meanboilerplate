export interface TaskItem {
    id: number;
    name: string;
    dueDate: string;
}