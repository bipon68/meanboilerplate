export interface PricingPlan {
    id?: number;
    name?: string;
    price?: number;
    icon?: string;
    duration?: string;
    features?: string[];
    recommended?: boolean;
}
