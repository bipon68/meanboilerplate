import { FeatherIconDirective } from './feather-icon.directive';

describe('FeatherIconDirective', () => {
  it('should create an instance', () => {
    const directive = new FeatherIconDirective();
    expect(directive).toBeTruthy();
  });
});
